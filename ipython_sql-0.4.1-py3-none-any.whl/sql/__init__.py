from .magic import *
